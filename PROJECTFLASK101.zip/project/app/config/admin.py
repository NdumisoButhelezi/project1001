"""Admin configuration settings"""

ADMIN_EMAIL = "admin@example.com"
ADMIN_PASSWORD = "admin123"  # Change this in production!